package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test2
 */
public class Test2 extends HttpServlet {
public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException{
		
		res.setContentType("application/msword");
		PrintWriter pw=res.getWriter();
		pw.println("<h1>welcome to servlet</h1>");
	}
}
