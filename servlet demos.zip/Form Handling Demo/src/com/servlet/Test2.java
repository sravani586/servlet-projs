package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test2
 */
public class Test2 extends HttpServlet {
public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
		
		String fn=req.getParameter("n1");
		String sn=req.getParameter("n2");
		int x=Integer.parseInt(fn);
		int y=Integer.parseInt(sn);
		int z=x+y;
		PrintWriter pw=res.getWriter();
		pw.println("<h1>");
		pw.println("sum of two numbers is");
		pw.println(z);
		pw.println("</h1>");
}
}
