package com.sevlet;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet
 */
public class HelloServlet extends GenericServlet {

	@Override
	public void init()
	{
		System.out.println(" i am init");
		
	}

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1){
		// TODO Auto-generated method stub
		System.out.println("i am service method executed for every business request");
		
	}
	
	@Override
	public void destroy(){
		System.out.println(" i am destroy method");
	}
	

}
